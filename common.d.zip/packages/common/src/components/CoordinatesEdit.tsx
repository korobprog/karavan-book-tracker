import React, { useState } from "react";
import { Button, InputNumber, Space } from "antd";
import { CheckOutlined, EditOutlined } from "@ant-design/icons";
import { LocationDoc, setCoordinates } from "common/src/services/api/locations";

type CoordinatesEditProps = {
  location: LocationDoc & { key: string };
  locations: LocationDoc[];
};

export const CoordinatesEdit: React.FC<CoordinatesEditProps> = (props) => {
  const { coordinates, ...location } = props.location;

  const [x, setX] = useState(coordinates?.[0] || 0);
  const [y, setY] = useState(coordinates?.[1] || 0);
  const [isEdit, setIsEdit] = useState(false);

  const toggleEdit = () => {
    setIsEdit(!isEdit);
  };

  const saveCoordinates = () => {
    const newLocation = props.locations.find((loc) => loc.id === location.key);
    if (newLocation && x && y) {
      setCoordinates(x, y, newLocation);
    }
    setIsEdit(false);
  };

  const displayedCoordinates = coordinates
    ? `${coordinates?.[0]}, ${coordinates?.[1]}`
    : "";

  return (
    <>
      {isEdit ? (
        <Space>
          <InputNumber defaultValue={x} onChange={(value) =>setX(value || 0)} />
          <InputNumber defaultValue={y} onChange={(value) =>setY(value || 0)} />
          <Button icon={<CheckOutlined />} onClick={saveCoordinates} />
        </Space>
      ) : (
        <Space>
          {displayedCoordinates}
          <Button icon={<EditOutlined />} onClick={toggleEdit} />
        </Space>
      )}
    </>
  );
};
