import 'common/src/app/offline/service-worker';
